import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, ReactiveFormsModule, FormControl, FormArray } from "@angular/forms";
import { forbiddenNameValidator } from "src/app/shared/user-name.validator";

import { RegistrationService } from "./registration.service";
import { Router } from "@angular/router";


@Component({
  selector: 'registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})

export class RegistrationComponent implements OnInit {

registrationForm : FormGroup;

get userName()
{
  return this.registrationForm.get('userName');
}

get email()
{
  return this.registrationForm.get('email');
}


ngOnInit()
{
  this.registrationForm = this.fb.group({
  userName : ['', [Validators.required, Validators.minLength(3), forbiddenNameValidator(/admin/)]],
  email : [''],     

});


this.registrationForm.get('userName').valueChanges
.subscribe(checkedValue => {
const email = this.registrationForm.get('email');

if(checkedValue)
{
  email.setValidators(Validators.required);
}

else{
  email.clearValidators();
}

email.updateValueAndValidity();
});
  
}

  constructor(private fb : FormBuilder, private registrationService : RegistrationService, private router : Router){}
  

  onSubmit() : void
  {
    console.log(this.registrationForm.value);
    this.registrationService.register(this.registrationForm.value).subscribe
    (
      response => console.log('Success', response),
      error => console.log('Error', error)
    );
        this.router.navigate(['/quiz', this.registrationForm.get('userName').value]);
  }
}
