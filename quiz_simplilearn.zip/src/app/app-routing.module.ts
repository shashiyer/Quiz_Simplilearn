import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegistrationComponent } from "src/registration/registration.component";
import { QuizComponent } from "src/quiz/quiz.component";


const routes: Routes = [
  { path : 'quiz/:name', component : QuizComponent },
  { path : '', component : RegistrationComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
